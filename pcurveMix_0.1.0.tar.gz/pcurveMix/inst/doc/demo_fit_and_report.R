## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup, message=FALSE, warning=FALSE--------------------------------------
library(ggplot2)
library(pcurveMix)
set.seed(1234)  # for reproducability

## ----generate-----------------------------------------------------------------
alpha_cutoff <- 1 # allow full range of p's, not selected for p<alpha significance
tails <- 2
true_mu <- 2
true_sigma <- 2
true_pi <- 0.2
n_ps <- 2000
#NEWJEFF: R complains about the next line. It says that "random" ist kein exportiertes Objekt aus 'namespace:pcurveMix
# AI says I should run this and then it worked....?  
#  devtools::document()
#  devtools::load_all()
#NEWROLF:
# This indicates that the above command "library(pcurveMix)"
# is not loading the latest version of the library. There was no
# function "random" in a previous version. I think it may be
# necessary to remove the old version of the library before
# attaching the new one?  Try using the RStudio commands
# > remove.packages("pcurveMix")
# > install.packages("path/to/pkgname.tar.gz", repos = NULL, type = "source", build_vignettes = TRUE)
# This should ensure that you have the latest version of the package.
# You might also remove some of the packages that give you the "erstellt"
# message about old versions.  Then RStudio will automatically install
# the latest versions.
sample_ps <- pcurveMix::random(n_ps, mu = true_mu, sigma = true_sigma, pi = true_pi, alpha = alpha_cutoff, tails = tails)

## -----------------------------------------------------------------------------
fit_results_list <- fit_p_curve(sample_ps, alpha = alpha_cutoff, tails = tails)
# print(fit_results_list)  # Ugly list format printing; better in next 2 tables.

## -----------------------------------------------------------------------------
descriptor_tbl <- fit_to_descriptor_tbl(fit_results_list)
print(descriptor_tbl)

## -----------------------------------------------------------------------------
estimates_tbl <- fit_to_estimates_tbl(fit_results_list)
print(estimates_tbl)

## -----------------------------------------------------------------------------
n_boot_samples <- 100  # 200 recommended minimum
df <- bootstrap(n_ps, fit_results_list, n_boot_samples, alpha = alpha_cutoff, tails = tails)
boot_tbl <- bootstrap_summary(df)
print(boot_tbl)

## ----out.width="100%"---------------------------------------------------------
combined_tbl <- merge_tables(estimates_tbl, boot_tbl)
combined_tbl[,-1] <- round(combined_tbl[,-1],3) # Round numeric columns to avoid line wrapping
print(combined_tbl)

## -----------------------------------------------------------------------------
# empirical <- ecdf(sample_ps)
p <- seq(0.001, alpha_cutoff, 0.002)
pred_pdfs <- pdf(p, mu = fit_results_list$mu, sigma = fit_results_list$sigma, pi = fit_results_list$pi,
                 alpha = alpha_cutoff, tails = tails)
pred_cdfs <- cdf(p, mu = fit_results_list$mu, sigma = fit_results_list$sigma, pi = fit_results_list$pi,
                 alpha = alpha_cutoff, tails = tails)

## ----fig.width=6--------------------------------------------------------------
# hist(sample_ps, freq = FALSE, xlim = c(0, alpha_cutoff) )
# lines(p, pred_pdfs, col = "red")
pdf_plot <- ggplot() + geom_histogram(aes(x = sample_ps, y = after_stat(density)), binwidth = 0.02) +
  geom_line(aes(x = p, y = pred_pdfs), color = "red")
print(pdf_plot)

## ----fig.width=6--------------------------------------------------------------
# plot(empirical, main = "Observed vs Predicted CDF", xlab = "p value", ylab = "CDF(p)",
#      xlim = c(0,1), ylim = c(0,1))
# lines(p, pred_cdfs, col = "red", lty = 1)
# legend(
#   "bottomright",
#   legend = c("observed", "predicted"),
#   lwd = 2,
#   lty = c(1, 1),
#   col = c("black", "red")
# )
cdf_df <- data.frame(x = sample_ps)
cdf_plot <- ggplot() +
  stat_ecdf(data = cdf_df, aes(x = x), geom = "step") +
  geom_line(aes(x = p, y = pred_cdfs), color = "red") +
  labs(title = "Observed (black) vs predicted (red) CDFs",
       x = "p value",
       y = "cumulative proportion")
print(cdf_plot)


## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(ggplot2)
library(pcurveMix)

## ----computations-------------------------------------------------------------
pi <- c(0.2, 0.8)
mu <- c(2, 3)
sigma <- 1
df_parms <- expand.grid(pi,mu,sigma)
names(df_parms) <- c("pi", "mu", "sigma")

p <- seq(0.001,0.999,0.002)
nps <- length(p)

df <- data.frame()

for (irow in 1:nrow(df_parms)) {
  pdfs <- pdf(p, mu = df_parms$mu[irow], sigma = df_parms$sigma[irow], pi = df_parms$pi[irow])
  cdfs <- cdf(p, mu = df_parms$mu[irow], sigma = df_parms$sigma[irow], pi = df_parms$pi[irow])
  df_row <- df_parms[rep(irow,nps),]
  df_row$p <- p
  df_row$pdf <- pdfs
  df_row$cdf <- cdfs
  df <- rbind(df, df_row)
}
df$mu <- as.factor(df$mu)
df$pi <- as.factor(df$pi)

## ----make_plots, fig.width=10, fig.height=10----------------------------------
pdf_fig <- ggplot() +
  geom_line(mapping = aes(x = p, y = pdf, linetype = pi, colour = mu), data = df, na.rm = TRUE) +
  ylim(-0.05,6.05)
print(pdf_fig)
cdf_fig <- ggplot() +
  geom_line(mapping = aes(x = p, y = cdf, linetype = pi, colour = mu), data = df) +
  ylim(-0.01,1.01)
print(cdf_fig)


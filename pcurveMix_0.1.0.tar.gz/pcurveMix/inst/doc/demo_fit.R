## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(pcurveMix)
set.seed(1234)  # for reproducability

## ----generate-----------------------------------------------------------------
ps_h0 <- runif(500)
ps_h1 <- runif(500)^4
ps <- c(ps_h0, ps_h1)
hist(ps)

## -----------------------------------------------------------------------------
fit_results_2tailed <- fit_p_curve(ps) # assumes 2-tailed p's in 0-1 range
print(fit_results_2tailed)

## -----------------------------------------------------------------------------
fit_results_1tailed <- fit_p_curve(ps, tails = 1)
print(fit_results_1tailed)

## -----------------------------------------------------------------------------
alpha <- 0.05
ps_sig <- ps[ps < alpha]

fit_sig_results_2tailed <- fit_p_curve(ps_sig, alpha = alpha) # assumes 2-tailed p's in 0-alpha range
print(fit_sig_results_2tailed)

fit_sig_results_1tailed <- fit_p_curve(ps_sig, alpha = alpha, tails = 1) # or assuming 1-tailed
print(fit_sig_results_1tailed)



REM ******** COPYING NEWER FILES TO GITHUB FOLDER:
@ECHO OFF
dirc DESCRIPTION ..\pkg.github copy1 newer1 only1
dirc LICENSE ..\pkg.github copy1 newer1 only1
dirc NAMESPACE ..\pkg.github copy1 newer1 only1
dirc README.md ..\pkg.github copy1 newer1 only1
dirc inst\*.*  ..\pkg.github\inst copy1 newer1 only1
dirc man\*.*  ..\pkg.github\man copy1 newer1 only1
dirc R\*.*  ..\pkg.github\R copy1 newer1 only1
dirc tests\*.*  ..\pkg.github\tests copy1 newer1 only1 /r
dirc vignettes\*.Rmd  ..\pkg.github\vignettes copy1 newer1 only1
pause

@ECHO ON
REM ******** CHECKING GITHUB FOLDER FOR NEWER FILES:
@ECHO OFF
dirc DESCRIPTION ..\pkg.github list2 newer2
dirc LICENSE ..\pkg.github list2 newer2
dirc NAMESPACE ..\pkg.github list2 newer2
dirc README.md ..\pkg.github list2 newer2
dirc inst\*.*  ..\pkg.github\inst list2 newer2
dirc man\*.*  ..\pkg.github\man list2 newer2
dirc R\*.*  ..\pkg.github\R list2 newer2
dirc tests\*.*  ..\pkg.github\tests list2 newer2 /r
dirc vignettes\*.Rmd  ..\pkg.github\vignettes list2 newer2
pause

@ECHO ON
REM ******** CHECKING GITHUB FOLDER FOR ORPHAN FILES:
@ECHO OFF
dirc DESCRIPTION ..\pkg.github list2 only2
dirc LICENSE ..\pkg.github list2 only2
dirc NAMESPACE ..\pkg.github list2 only2
dirc README.md ..\pkg.github list2 only2
dirc inst\*.*  ..\pkg.github\inst list2 only2
dirc man\*.*  ..\pkg.github\man list2 only2
dirc R\*.*  ..\pkg.github\R list2 only2
dirc tests\*.*  ..\pkg.github\tests list2 only2 /r
dirc vignettes\*.Rmd  ..\pkg.github\vignettes list2 only2
@ECHO ON

REM Local pkg.github folder is now current.
REM Run GitHub Desktop to update repo.
